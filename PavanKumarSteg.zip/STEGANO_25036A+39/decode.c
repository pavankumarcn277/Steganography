#include<stdio.h>
#include<string.h>
#include"common.h"
#include "decode.h"
// #include "types.h"
#define MAGIC_STRING "#*"
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo)  
{
    
    if(strstr(argv[2],".bmp")!=NULL)
    {
        decInfo->src_image_fname=argv[2];
        return e_success;
    }
    return e_failure;
}
Status do_decoding(DecodeInfo *decInfo)
{
    if(open_dfiles(decInfo)==e_success)  //to open the file and check for the return value from the function
    {
        printf("Files opened successfully\n");
        if(decode_magic_string(MAGIC_STRING,decInfo)==e_success)//to decode the magic string and check for the return value from the function
        {  
            printf("Magic strings are decoded successfully\n");
            if(decode_secret_file_extn_size(decInfo)==e_success)//to decode the secret file extn size and check for the return value from the function
            {
                printf("Decoded secret file extn size\n");
                if(decode_secret_file_extn(decInfo)==e_success)//to decode the secret file extn and check for the return value from the function
                {
                    
                    printf("Decoded secret file extention\n");
                    if(decode_secret_file_size(decInfo)==e_success)//to decode the secret file size and check for the return value from the function
                    {
                        printf("Decoded the size of file\n");
                        if(decode_secret_file_data(decInfo)==e_success)//to decode the secret file data and check for the return value from the function
                        
                        {
                            printf("Decoded completely\n");
                        }
                        else
                        {
                            printf("Decoding incomnplete\n");
                        }
                    }
                    else
                    {
                        printf("Failed to decode size of file\n");
                    }
                }
                else
                {
                    printf("Secret file extention decoding failed\n");
                }
            }
            else
            {
                printf("Decoding secret file extn size failed\n");
            }
        }
        else
        {
            printf("Decoding magic failed\n");
        }
    }
    else
    {
        printf("Files open failed\n");
        return e_failure;
    }
}
Status open_dfiles(DecodeInfo *decInfo)  //Logic to open the file
{
    decInfo->fptr_src_image = fopen(decInfo->src_image_fname, "r");
    // Do Error handling
    if (decInfo->fptr_src_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->src_image_fname);
        return e_failure;
    }
    printf("%s\n",decInfo->src_image_fname);
    return e_success;
}
Status decode_magic_string(const char* magic_string,DecodeInfo *decInfo)
{
    char arr[3]={'#','*','\0'};  //Temp array
    char buffer[8];  //Temp buffer to read from file and store
    fseek(decInfo->fptr_src_image,54,SEEK_SET);  //Skipping 54 header bits 
    for(int i=0;i<strlen(magic_string);i++)  //Logic to read and compare the magic string
    {
        fread(buffer,1,8,decInfo->fptr_src_image);
        if(decode_byte_to_lsb(buffer)!=arr[i])
        {
            return e_failure;
        }
    }
    return e_success;
}
unsigned char decode_byte_to_lsb(char *buffer)  //Logic to decode bytes from lsb 
{
    unsigned char c=0;
    for(int i=0;i<=7;i++)
    {
       //c|=((buffer[i] & ( 1 << 0 )) << (7-i));
       c = (c <<  1)  | (buffer[i] &1); 
    }
    
    return c;
   
}
Status decode_secret_file_extn_size(DecodeInfo *decInfo)  //Logic to decode the extn size and store it
{
    char buffer[32];
    fread(buffer,sizeof(char),32,decInfo->fptr_src_image);
    decInfo->size_extn_file=decode_size_to_lsb(buffer);
    return e_success;
}
unsigned int decode_size_to_lsb(char *imageBuffer)  //Logic to decode size from lsb
{
    unsigned int size=0;
    for(int i=0;i<=31;i++)
    {
        size=size|((imageBuffer[i]&(1<<0))<<(31-i));
    }
    return size;
}
Status decode_secret_file_extn( DecodeInfo *decInfo)  //Logic to decode and store the extention
{
    char buffer[8];
    int i;
    for( i=0;i<decInfo->size_extn_file;i++)
    {
        fread(buffer,sizeof(char),8,decInfo->fptr_src_image);
    
        decInfo->extn_secret_file[i]=decode_byte_to_lsb(buffer);
       // decInfo->extn_secret_file[i]=decode_byte_to_lsb(buffer,);

    }   
    decInfo->extn_secret_file[i]='\0';  //After finding extention add null character to the end
    strcat(decInfo->output_fname,decInfo->extn_secret_file);//combine the name passed by user and the extention decoded
    decInfo->fptr_output=fopen(decInfo->output_fname,"w"); //Open the file in wss mode
    return e_success;

}
Status decode_secret_file_size(DecodeInfo *decInfo)  //Logic to decode 4 bytes of size from lsb
{
    char buffer[32];
    fread(buffer,1,32,decInfo->fptr_src_image);
    decInfo->size_output_file=decode_size_to_lsb(buffer);
   // printf("%ld\n",decInfo->size_output_file);
    return e_success;

}
Status decode_secret_file_data(DecodeInfo *decInfo)  //Loic to decode and write the data in new file which has the extn which is sent in the file
{
    char buffer[8];
    
    for(int i=0;i<(decInfo->size_output_file);i++)
    {
        fread(buffer,1,8,decInfo->fptr_src_image);
        putc(decode_byte_to_lsb(buffer),decInfo->fptr_output);
    }
    return e_success;
}