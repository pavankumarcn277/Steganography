#ifndef DECODE_H
#define DECODE_H
#include <stdio.h>
#include<string.h>

#include "types.h"
#endif
typedef struct Decode_Info
{
    /* Source Image info */
    char *src_image_fname;
    FILE *fptr_src_image;  
    //uint image_capacity;   

    /* Secret File Info */
    char *output_fname;       
    FILE *fptr_output;     
    char extn_secret_file[5]; 
    // char secret_data[100];    
    long size_output_file;   
    long size_extn_file;  
    /* Stego Image Info */
    // char *stego_image_fname; 
    // FILE *fptr_stego_image;  

} DecodeInfo;
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo);

/* Perform the encoding */
Status do_decoding(DecodeInfo *decInfo);

/* Get File pointers for i/p and o/p files */
Status open_dfiles(DecodeInfo *decInfo);
Status decode_magic_string(const char* magic_string,DecodeInfo *decInfo);

/*Encode extension size*/
Status decode_secret_file_extn_size( DecodeInfo *decInfo);

/* Encode secret file extenstion */
Status decode_secret_file_extn( DecodeInfo *decInfo);

/* Encode secret file size */
Status decode_secret_file_size( DecodeInfo *decInfo);

/* Encode secret file data*/
Status decode_secret_file_data(DecodeInfo *decInfo);

/* Encode a byte into LSB of image data array */
unsigned char decode_byte_to_lsb(char buffer[] );

// Encode a size to lsb
unsigned int decode_size_to_lsb( char *imageBuffer);