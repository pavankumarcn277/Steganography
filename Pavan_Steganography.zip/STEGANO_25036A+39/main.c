/*Pavan Kumar C N
25036A
16/2/2026
Steganography prok=ject
*/
#include <stdio.h>
#include"decode.h"
#include "encode.h"
#include "types.h"
char arr[7]="Output";

OperationType check_operation_type(char *);

int main(int argc, char *argv[])
{
    //step1 -> check_operation_type(argv[1])
    
    OperationType checkop=(check_operation_type(argv[1]));
    if(checkop==e_encode)
    {
        if(argc<4)
        {
            printf("Less CLA passed\n");
            return 1;
        }
        EncodeInfo encInfo;
        if(read_and_validate_encode_args(argv,&encInfo)==e_success)
        {
            
            if(do_encoding(&encInfo)==e_failure)
            {
                printf("Encoding failed\n");
            }
            else
            {
                printf("Returned e_success from do encoding part\n");
            }
        }
        else
        {
            printf("CLA arguments are not of proper file format\n");
            return 1;  
        }
    }
    else if(checkop==e_decode)  //If operation is decode
    {
        if(argc<3)
        {
            printf("Less command line arguments passed\n");
            return 1;
        }
        DecodeInfo decInfo;
        if(argc==4)
        {
            decInfo.output_fname=strtok(argv[3],".");
        }
        else
        {

            decInfo.output_fname=arr;
        }
        if(read_and_validate_decode_args(argv,&decInfo)==e_success)
        {
            printf("Read and validate success\n");
            if(do_decoding(&decInfo)==e_success)
            {
                printf("Decoding successful\n");
            }
        }
    }
    else
    {
        printf("Operation is not selected properly\n");
    }

    //step2 -> check the return value == e_encode
            //declare structure variable EncodeInfo encInfo
            //--> read_and_validate_encode_args(pass command line arg, &encInfo) == e_success or e_failure
            // e_failure -> print error msg and stop the program
            // e_success -> next step.
        // call do_encoding(&encInfo);
            //e_failure -> print error msg and stop the program


    //step3 -> return value == e_decode
            // --
    //step3 -> return value == e_unsupported
            // --> print invalid arg
            // -e -> encode
            // -d  -> decode
}

OperationType check_operation_type(char *symbol)
{
    //step1 -> check it is -e or -d 
    
    if(strcmp(symbol,"-e")== 0)
    {
        return e_encode;
    }
    else if(strcmp(symbol,"-d")==0)
    {
        return e_decode;
    }
    else
    {
        return e_unsupported;
    }
    // if it is -e return e_encode
    // else if it is -d rteun e_decode
    // else return e_unsuported
}
